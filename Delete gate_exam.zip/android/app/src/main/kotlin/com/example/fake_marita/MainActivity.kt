package com.example.fake_marita

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

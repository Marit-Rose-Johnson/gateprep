# 🎯 Gate_prep

A Flutter application designed to help students prepare for the GATE exam.

## 🚀 Features

- Multiple-choice quiz functionality
- Timer-based tests
- Performance tracking
- Organized by subjects and topics

## 🛠️ Getting Started

To run this project locally:

```bash
git clone https://github.com/your-username/Gate_prep.git
cd Gate_prep
flutter pub get
flutter run

